package com.trinity.weaver.dao;

import java.util.ArrayList;

import com.trinity.weaver.dto.ZipcodeDto;

public interface ZipcodeDao {
	public void zipcodeInsert(final String zipcode, final String area1, final String area2, final String area3, final String area4, final String roadName, final String buildingName);
	public ArrayList<ZipcodeDto> list();
	
	
	

}
