package com.trinity.weaver.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.ZipcodeDao;

public class ZipcodeInsertService implements WeaverService {
   // MyBatis 사용을 위해서 SqlSession 객체 생성.
   private SqlSession sqlSession = Constant.sqlSession;

   @Override
   public void execute(Model model) {
      // TODO 폼에서 전달받은 정보를 데이타베이스에 등록
      Map<String, Object> map = model.asMap(); // Model이 가진 정보를 map으로 전환해서 하나씩 꺼냄.
      // get()은 리턴값이 Object임.(그렇기 때문에 HttpServletRequest로 형변환이 가능함.)
      HttpServletRequest request = (HttpServletRequest) map.get("request"); // map에서 정보를 얻어와서 request라는 맵에 넣어줌.

      // ZipcodeDao.xml #zipcodeInsert부분에 필요한 파라미터의 수 만큼 작성.
      String zipcode = request.getParameter("zipcode");
      String area1 = request.getParameter("area1");
      String area2 = request.getParameter("area2");
      String area3 = request.getParameter("area3");
      String area4 = request.getParameter("area4");
      String roadName = request.getParameter("roadName");
      String buildingName = request.getParameter("buildingName");

      // DAO 부리기
      ZipcodeDao dao = sqlSession.getMapper(ZipcodeDao.class); // MyBatis가 ZipcodeDao 타입으로 클래스를 만들어 준다.
      // 인터페이스 , ZipcodeDao.xml #zipcodeInsert, 서비스의 zipcodeInsert 세가지는 모두 일치해야 한다.
      dao.zipcodeInsert(zipcode, area1, area2, area3, area4, roadName, buildingName);
   }

}