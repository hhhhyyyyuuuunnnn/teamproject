package com.trinity.weaver.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.QstnDao;

public class QstnUpdateService implements WeaverService {
	private SqlSession sqlSession = Constant.sqlSession;

	@Override
	public void execute(Model model) {
		Map<String, Object> map = model.asMap();
		HttpServletRequest request = (HttpServletRequest) map.get("request");
		
		int qstnbrd_idx = Integer.parseInt(request.getParameter("qstnbrd_idx"));
		String qstncat_name = request.getParameter("qstncat_name");
		int cust_idx = Integer.parseInt(request.getParameter("cust_idx"));
		String qstnbrd_title = request.getParameter("qstnbrd_title");
		String qstnbrd_content = request.getParameter("qstnbrd_content");
		String qstnbrd_imgName = request.getParameter("qstnbrd_imgName");
		String qstnbrd_imgPath = request.getParameter("qstnbrd_imgPath");
		char qstnbrd_secret = charset(request.getParameter("qstnbrd_secret"));
		//char 타입은 어케 해야하나
		String qstnbrd_pw = request.getParameter("qstnbrd_pw");
		
		QstnDao dao = sqlSession.getMapper(QstnDao.class);
		dao.qstnUpdate(qstnbrd_idx, qstncat_name, cust_idx, qstnbrd_title, qstnbrd_content, qstnbrd_imgName, qstnbrd_imgPath, qstnbrd_secret, qstnbrd_pw);

	}

	private char charset(String parameter) {
		// TODO Auto-generated method stub
		return 0;
	}

}
