package com.trinity.weaver.service;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.ZipcodeDao;
import com.trinity.weaver.dto.ZipcodeDto;

public class ZipcodeListService implements WeaverService {
	   
	   // SqlSession은 MyBatis의 객체를 의미함.
	   private SqlSession sqlSession = Constant.sqlSession;
	   
	   @Override
	   public void execute(Model model) {
	      // MyBatis가 mapper와 DAO를 연결시켜서 DAO를 만들어주는 소스.
	      // DAO의 타입은 인터페이스에서 만든 타입으로 만듬.
	      ZipcodeDao dao = sqlSession.getMapper(ZipcodeDao.class);
	      // DAO실행.
	      ArrayList<ZipcodeDto> dtos = dao.list();
	      // JSP에서는 list라는 이름으로 담아서 전달한다는 의미, 실제로 전달은 Servlet으로 처리함.
	      // service를 실행시키면 모델에 "list"가 올라감.
	      model.addAttribute("list", dtos);
	   }

}
