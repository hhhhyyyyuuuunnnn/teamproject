package com.trinity.weaver.dao;

import java.util.ArrayList;

import com.trinity.weaver.dto.QstnDto;

public interface QstnDao {
	//리스트 조회
	public ArrayList<QstnDto> qstnList();
	//제품 등록
	public void qstnInsert(
			String qstncat_name,
			int cust_idx,
			String qstnbrd_title,
			String qstnbrd_content,
			String qstnbrd_imgName,
			String qstnbrd_imgPath,
			String qstnbrd_pw
			);//final char qstnbrd_secret 비밀글 보류 -> 아마 db엔0으로 자동 저장되서 할 필요없을듯
	
	
	public QstnDto qstnContentView(int strID);
	
	public void qstnUpdate( //qstn_secret때문에 <Char>타입 추가됨
			final int qstnbrd_idx,
			final String qstncat_name,
			final int cust_idx,
			final String qstnbrd_title,
			final String qstnbrd_content,
			final String qstnbrd_imgName,
			final String qstnbrd_imgPath,
			final char qstnbrd_secret,
			final String qstnbrd_pw
			);
	
	//체험 삭제
	public void qstnDelete(final int qstnbrd_idx);

}
