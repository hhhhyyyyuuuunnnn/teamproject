package com.trinity.weaver.dto;

public class ZipcodeDto {
	private int zipcodeIdx; //자바에서는 언더바 사용x
	private String zipcode;
	private String area1;
	private String area2;
	private String area3;
	private String area4;
	private String roadName;
	private String buildingName;
		
	//일반생성자
	public ZipcodeDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//기본생성자
	public ZipcodeDto(int zipcodeIdx, String zipcode, String area1, String area2, String area3, String area4,
			String roadName, String buildingName) {
		super();
		this.zipcodeIdx = zipcodeIdx;
		this.zipcode = zipcode;
		this.area1 = area1;
		this.area2 = area2;
		this.area3 = area3;
		this.area4 = area4;
		this.roadName = roadName;
		this.buildingName = buildingName;
	}
	
	//getters와 setters
	public int getZipcodeIdx() {
		return zipcodeIdx;
	}

	public void setZipcodeIdx(int zipcodeIdx) {
		this.zipcodeIdx = zipcodeIdx;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getArea1() {
		return area1;
	}

	public void setArea1(String area1) {
		this.area1 = area1;
	}

	public String getArea2() {
		return area2;
	}

	public void setArea2(String area2) {
		this.area2 = area2;
	}

	public String getArea3() {
		return area3;
	}

	public void setArea3(String area3) {
		this.area3 = area3;
	}

	public String getArea4() {
		return area4;
	}

	public void setArea4(String area4) {
		this.area4 = area4;
	}

	public String getRoadName() {
		return roadName;
	}

	public void setRoadName(String roadName) {
		this.roadName = roadName;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	
}
