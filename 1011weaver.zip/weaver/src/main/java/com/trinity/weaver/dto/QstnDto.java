package com.trinity.weaver.dto;

import java.util.Date;

public class QstnDto {
	private int qstnbrd_idx;
	private String qstncat_name;
	private int cust_idx;
	private String qstnbrd_title;
	private String qstnbrd_content;
	private Date qstnbrd_date;
	private String qstnbrd_imgName;
	private String qstnbrd_imgPath;
	private char qstnbrd_secret;
	private String qstnbrd_pw;
	
	public QstnDto() {}

	public QstnDto(int qstnbrd_idx, String qstncat_name, int cust_idx, String qstnbrd_title, String qstnbrd_content,
			Date qstnbrd_date, String qstnbrd_imgName, String qstnbrd_imgPath, char qstnbrd_secret, String qstnbrd_pw) {
		super();
		this.qstnbrd_idx = qstnbrd_idx;
		this.qstncat_name = qstncat_name;
		this.cust_idx = cust_idx;
		this.qstnbrd_title = qstnbrd_title;
		this.qstnbrd_content = qstnbrd_content;
		this.qstnbrd_date = qstnbrd_date;
		this.qstnbrd_imgName = qstnbrd_imgName;
		this.qstnbrd_imgPath = qstnbrd_imgPath;
		this.qstnbrd_secret = qstnbrd_secret;
		this.qstnbrd_pw = qstnbrd_pw;
	}

	public int getQstnbrd_idx() {
		return qstnbrd_idx;
	}

	public void setQstnbrd_idx(int qstnbrd_idx) {
		this.qstnbrd_idx = qstnbrd_idx;
	}

	public String getQstncat_name() {
		return qstncat_name;
	}

	public void setQstncat_name(String qstncat_name) {
		this.qstncat_name = qstncat_name;
	}

	public int getCust_idx() {
		return cust_idx;
	}

	public void setCust_idx(int cust_idx) {
		this.cust_idx = cust_idx;
	}

	public String getQstnbrd_title() {
		return qstnbrd_title;
	}

	public void setQstnbrd_title(String qstnbrd_title) {
		this.qstnbrd_title = qstnbrd_title;
	}

	public String getQstnbrd_content() {
		return qstnbrd_content;
	}

	public void setQstnbrd_content(String qstnbrd_content) {
		this.qstnbrd_content = qstnbrd_content;
	}

	public Date getQstnbrd_date() {
		return qstnbrd_date;
	}

	public void setQstnbrd_date(Date qstnbrd_date) {
		this.qstnbrd_date = qstnbrd_date;
	}

	public String getQstnbrd_imgName() {
		return qstnbrd_imgName;
	}

	public void setQstnbrd_imgName(String qstnbrd_imgName) {
		this.qstnbrd_imgName = qstnbrd_imgName;
	}

	public String getQstnbrd_imgPath() {
		return qstnbrd_imgPath;
	}

	public void setQstnbrd_imgPath(String qstnbrd_imgPath) {
		this.qstnbrd_imgPath = qstnbrd_imgPath;
	}

	public char getQstnbrd_secret() {
		return qstnbrd_secret;
	}

	public void setQstnbrd_secret(char qstnbrd_secret) {
		this.qstnbrd_secret = qstnbrd_secret;
	}

	public String getQstnbrd_pw() {
		return qstnbrd_pw;
	}

	public void setQstnbrd_pw(String qstnbrd_pw) {
		this.qstnbrd_pw = qstnbrd_pw;
	}
	
}
