package com.trinity.weaver.service;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.ProdRevDao;
import com.trinity.weaver.dto.ProdRevDto;


public class ProdRevListService implements WeaverService {
	   private SqlSession sqlSession = Constant.sqlSession;

	@Override
	public void execute(Model model) {
		ProdRevDao dao = sqlSession.getMapper(ProdRevDao.class);
		System.out.println("dao"+dao);
		ArrayList<ProdRevDto> dtos = dao.list();
		System.out.println(dtos);
		model.addAttribute("list", dtos);
		
		
	}
}
