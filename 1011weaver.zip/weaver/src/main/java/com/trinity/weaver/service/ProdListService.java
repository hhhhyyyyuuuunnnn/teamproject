package com.trinity.weaver.service;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.ProdDao;
import com.trinity.weaver.dto.ProdDto;


public class ProdListService implements WeaverService {
	   private SqlSession sqlSession = Constant.sqlSession;

	@Override
	public void execute(Model model) {
		ProdDao dao = sqlSession.getMapper(ProdDao.class);
		ArrayList<ProdDto> dtos = dao.prodList();
		model.addAttribute("prodList", dtos);
	}
}
