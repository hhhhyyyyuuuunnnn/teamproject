package com.trinity.weaver.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.QstnDao;
import com.trinity.weaver.dto.QstnDto;


public class QstnListService implements WeaverService {
	private SqlSession sqlSession = Constant.sqlSession;
	
	public static final int MESSAGE_COUNT_PER_PAGE = 10;

	@Override
	public void execute(Model model) {
		QstnDao dao = sqlSession.getMapper(QstnDao.class);
		ArrayList<QstnDto> dtos = dao.qstnList();
		model.addAttribute("qstnList", dtos);
	}
	
	public List<QstnDto> selectList(int a, int z) throws SQLException{
		QstnDao dao = sqlSession.getMapper(QstnDao.class);
		ArrayList<QstnDto> dtos = dao.qstnList();
		
		return dtos.subList(a-1, z);
	}
	
	public MessageListView getMessageListView(int pageNumber) throws SQLException{
		int currentPageNumber = pageNumber;
		QstnDao dao = sqlSession.getMapper(QstnDao.class);
		int messageTotalCount = dao.qstnList().size();
		List<QstnDto> messageList = null;
		int firstRow = 0;
		int endRow = 0;	
		if(messageTotalCount > 0) {
			// 예시. 10페이지를 보여달라고 가정. - firstRow = (10-1) * 10 +1 -> 90+1 -> 결과값 91.
			// 즉, 10페이지의 첫 행은 91번 자료임.
		firstRow = (pageNumber - 1) * MESSAGE_COUNT_PER_PAGE+1;
		// 예시. 10페이지를 보여달라고 가정. endRow = 91+10-1 -> 결과값 100.
			// 즉, 10페이지의 마지막 행은 100번 자료임.
		endRow = firstRow + MESSAGE_COUNT_PER_PAGE-1;
		
		// 예시. 총 게시글 수가 98개라면, endRow가 98이어야 하지 100이면 틀림.
			//  마지막 자료보다 큰 인덱스값으면 안된다.
		if(endRow > messageTotalCount) {
			// endRow값이 총 게시글의 마지막 인덱스값보다 크면, 마지막 인덱스값이 리턴.
			endRow = messageTotalCount;
		}
			messageList = selectList(firstRow, endRow);
		} else {
			// 현재 페이지가 0이면 emptyList()가 리턴.
			currentPageNumber = 0;
			messageList = Collections.emptyList();
		}
		return new MessageListView(messageTotalCount, currentPageNumber, messageList, MESSAGE_COUNT_PER_PAGE, firstRow, endRow);
		
	}

}
