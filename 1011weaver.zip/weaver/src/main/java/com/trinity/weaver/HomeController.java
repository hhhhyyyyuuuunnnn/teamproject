package com.trinity.weaver;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.trinity.weaver.service.Constant;
import com.trinity.weaver.service.QstnContentViewService;
import com.trinity.weaver.service.QstnDeleteService;
import com.trinity.weaver.service.QstnInsertService;
import com.trinity.weaver.service.QstnListService;
import com.trinity.weaver.service.QstnUpdateService;
import com.trinity.weaver.service.WeaverService;
import com.trinity.weaver.service.ZipcodeInsertService;
import com.trinity.weaver.service.ZipcodeListService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	// service 황용
	WeaverService service;
	SqlSession sqlSession;
	
	//컨트롤러에서 SqlSession 객체를 사용하기 위한 코드, @Autowired 가 붙으면 무조건 수행됨
	@Autowired
	   public void setSqlSession(SqlSession sqlSession) {
	      this.sqlSession = sqlSession;
	      // 이 부분으로 인해, Contstant를 통해 다른 클래스들도 SqlSession 객체를 사용할 수 있음.
	         // 즉, 서블릿에서 생성 Constant 클래스로 보내줌.
	            // 따라서, 서비스에서 Constatn로 접근해서 SqlSession을 생성할 수 있음.
	      Constant.sqlSession = this.sqlSession;
	   }   
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	//url에 "zipcodeInsert"라고 입력하여 접속했을때.
	@RequestMapping("/zipcodeInsert")
	public String insert(Model model, HttpServletRequest request) throws SQLException, IOException{ // Model에 필요한 정보를 담에서 JSP로 전달함.
		System.out.println("write() 실행");
	      
	    // Model에 request를 담기.
	    model.addAttribute("request", request);
	    // service 객체 생성
	    service = new ZipcodeInsertService();
	      
	    // service 실행
	    service.execute(model);
	      
	    return "redirect:list"; // list페이지로 전환시키기.
	 }
	
	// url에 "zipcodeListService"라고 입력하여 접속했을때.
	@RequestMapping("/zipcodeListService")
	public String list(Model model) { // Model에 필요한 정보를 담에서 JSP로 전달함.
		System.out.println("list() 실행");
	      
	    service = new ZipcodeListService();
	    service.execute(model);
	      
	    return "list"; // 확장자를 적지 않아도 list.jsp로 전달.
	   }
	
	@RequestMapping("/qstnList")
	public String qstnList(Model model) {
		System.out.println("qstnList() 실행");
		
		service = new QstnListService();
		service.execute(model);
		
		return "qstnList";
	}

	@RequestMapping("/qstnInsert")
	public String qstnInsert(Model model, HttpServletRequest request) throws SQLException, IOException{ 
		System.out.println("qstnInsert() 실행");
		
		model.addAttribute("request", request);
		service = new QstnInsertService();
		service.execute(model);
		
		return "redirect:qstnList";
	}
	
	@RequestMapping("/qstnInsert_view")
	public String qstnInsert_view(Model model) { 
		System.out.println("qstnInsert_view() 실행");
		
		return "qstnInsert_view";
	}
	
	@RequestMapping("/qstnContent_view")
	public String qstnContent_view(Model model, HttpServletRequest request) throws SQLException, IOException {
		System.out.println("qstnContent_view() 실행");
		
		model.addAttribute("request", request);
		service = new QstnContentViewService();
		service.execute(model);
		
		return "qstnContent_view";
	}
	
	@RequestMapping("/qstnUpdate")
	public String qstnUpdate(Model model, HttpServletRequest request){
		System.out.println("qstnUpdate() 실행");
		
		model.addAttribute("request", request);
		service = new QstnUpdateService();
		service.execute(model);
		
		return "redirect:qstnList";
	}
	
	@RequestMapping("/qstnDelete")
	public String qstnDelete(Model model, HttpServletRequest request){
		System.out.println("qstnDelete() 실행");
		
		model.addAttribute("request", request);
		service = new QstnDeleteService();
		service.execute(model);
		
		return "redirect:qstnList";
	}
}
