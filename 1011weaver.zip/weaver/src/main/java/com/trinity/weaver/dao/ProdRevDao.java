package com.trinity.weaver.dao;

import java.util.ArrayList;

import com.trinity.weaver.dto.ProdRevDto;

public interface ProdRevDao {
	//리스트 조회
	public ArrayList<ProdRevDto> list();
	//리뷰 등록
	public void write(final String prodRevTitle, final String prodRevContent, final int prodRevScore);

}
