package com.trinity.weaver.dto;

import java.sql.Date;

public class ProdRevDto {
	private int prodRevIdx;
	private String prodRevTitle;
	private String prodRevContent;
	private String prodRevReply;
	private String prodRevImgName;
	private String prodRevImgPath;
	private int prodRevScore;
	private int prodRevEmpaty;
	private int prodRevHit;
	private Date prodRevDate;
	
	public ProdRevDto() {}

	//전체생성자
	public ProdRevDto(int prodRevIdx, String prodRevTitle, String prodRevContent, String prodRevReply,
			String prodRevImgName, String prodRevImgPath, int prodRevScore, int prodRevEmpaty, int prodRevHit,
			Date prodRevDate) {
		super();
		this.prodRevIdx = prodRevIdx;
		this.prodRevTitle = prodRevTitle;
		this.prodRevContent = prodRevContent;
		this.prodRevReply = prodRevReply;
		this.prodRevImgName = prodRevImgName;
		this.prodRevImgPath = prodRevImgPath;
		this.prodRevScore = prodRevScore;
		this.prodRevEmpaty = prodRevEmpaty;
		this.prodRevHit = prodRevHit;
		this.prodRevDate = prodRevDate;
	}
	
//	//리뷰 등록
//	public ProdRevDto(String prodRevTitle, String prodRevContent, String prodRevImgName, String prodRevImgPath,
//			int prodRevScore,  int prodRevHit, Date prodRevDate) {
//		super();
//		this.prodRevTitle = prodRevTitle;
//		this.prodRevContent = prodRevContent;
//		this.prodRevImgName = prodRevImgName;
//		this.prodRevImgPath = prodRevImgPath;
//		this.prodRevScore = prodRevScore;
//		this.prodRevHit = prodRevHit;
//		this.prodRevDate = prodRevDate;
//	}

	public int getProdRevIdx() {
		return prodRevIdx;
	}

	public void setProdRevIdx(int prodRevIdx) {
		this.prodRevIdx = prodRevIdx;
	}

	public String getProdRevTitle() {
		return prodRevTitle;
	}

	public void setProdRevTitle(String prodRevTitle) {
		this.prodRevTitle = prodRevTitle;
	}

	public String getProdRevContent() {
		return prodRevContent;
	}

	public void setProdRevContent(String prodRevContent) {
		this.prodRevContent = prodRevContent;
	}

	public String getProdRevReply() {
		return prodRevReply;
	}

	public void setProdRevReply(String prodRevReply) {
		this.prodRevReply = prodRevReply;
	}

	public String getProdRevImgName() {
		return prodRevImgName;
	}

	public void setProdRevImgName(String prodRevImgName) {
		this.prodRevImgName = prodRevImgName;
	}

	public String getProdRevImgPath() {
		return prodRevImgPath;
	}

	public void setProdRevImgPath(String prodRevImgPath) {
		this.prodRevImgPath = prodRevImgPath;
	}

	public int getProdRevScore() {
		return prodRevScore;
	}

	public void setProdRevScore(int prodRevScore) {
		this.prodRevScore = prodRevScore;
	}

	public int getProdRevEmpaty() {
		return prodRevEmpaty;
	}

	public void setProdRevEmpaty(int prodRevEmpaty) {
		this.prodRevEmpaty = prodRevEmpaty;
	}

	public int getProdRevHit() {
		return prodRevHit;
	}

	public void setProdRevHit(int prodRevHit) {
		this.prodRevHit = prodRevHit;
	}

	public Date getProdRevDate() {
		return prodRevDate;
	}

	public void setProdRevDate(Date prodRevDate) {
		this.prodRevDate = prodRevDate;
	}
	

}
