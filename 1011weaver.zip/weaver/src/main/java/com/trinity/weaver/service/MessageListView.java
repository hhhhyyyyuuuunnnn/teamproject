package com.trinity.weaver.service;

import java.util.List;

import com.trinity.weaver.dto.QstnDto;

public class MessageListView {
	private int messageTotalCount;
	private int currentPageNumber;
	private List<QstnDto> messageList;
	private int messageCountPerPage;
	private int firstRow;
	private int endRow;
	
	private int pageTotalCount;

	public MessageListView(int messageTotalCount, int currentPageNumber, List<QstnDto> messageList,
			int messageCountPerPage, int firstRow, int endRow) {
		super();
		this.messageTotalCount = messageTotalCount;
		this.currentPageNumber = currentPageNumber;
		this.messageList = messageList;
		this.messageCountPerPage = messageCountPerPage;
		this.firstRow = firstRow;
		this.endRow = endRow;
		
		//pageTotalCount는 이걸로 처리
		calculatePageTotalcount();
	}

	private void calculatePageTotalcount() {
		if(messageTotalCount == 0) {
			pageTotalCount = 0;
		} else {
			pageTotalCount = messageTotalCount / messageCountPerPage;
			
			if(messageTotalCount % messageCountPerPage > 0) {
				pageTotalCount++;
			}
		}
	}
	
	//setter는 필요x
	public int getMessageTotalCount() {
		return messageTotalCount;
	}

	public int getCurrentPageNumber() {
		return currentPageNumber;
	}

	public List<QstnDto> getMessageList() {
		return messageList;
	}

	public int getMessageCountPerPage() {
		return messageCountPerPage;
	}

	public int getFirstRow() {
		return firstRow;
	}

	public int getEndRow() {
		return endRow;
	}

	public int getPageTotalCount() {
		return pageTotalCount;
	}
	
	public boolean isEmpty() {
		return messageTotalCount == 0; // true는 자료없음, false는 자료있음
	}

}
