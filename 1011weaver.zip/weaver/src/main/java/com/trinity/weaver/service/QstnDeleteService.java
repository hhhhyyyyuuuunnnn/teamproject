package com.trinity.weaver.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.QstnDao;

public class QstnDeleteService implements WeaverService {
	private SqlSession sqlSession = Constant.sqlSession;

	@Override
	public void execute(Model model) {
		
		Map<String, Object> map = model.asMap(); 
		HttpServletRequest request = (HttpServletRequest) map.get("request"); 
		
		int qstnbrd_idx = Integer.parseInt(request.getParameter("qstnbrd_idx"));
		
		QstnDao dao = sqlSession.getMapper(QstnDao.class);
		dao.qstnDelete(qstnbrd_idx);
		

	}

}
