package com.trinity.weaver.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.ProdDao;

public class ProdWriteService implements WeaverService {
	private SqlSession sqlSession = Constant.sqlSession;

	@Override
	public void execute(Model model) {
		Map<String, Object> map = model.asMap();
		//final String prod_name, final int prod_price, final int prod_stock, final String prod_desc, final String prod_imgName, final String prod_imgPath
		HttpServletRequest request = (HttpServletRequest) map.get("request");
		String prod_name = request.getParameter("prod_name");
		int prod_price = Integer.parseInt(request.getParameter("prod_price"));
		int prod_stock = Integer.parseInt(request.getParameter("prod_stock"));
		String prod_desc = request.getParameter("prod_desc");
		String prod_imgName = request.getParameter("prod_imgName");
		String prod_imgPath = request.getParameter("prod_imgPath");
		ProdDao dao = sqlSession.getMapper(ProdDao.class);
		dao.write(prod_name, prod_price, prod_stock, prod_desc, prod_imgName, prod_imgPath);
	}

}
