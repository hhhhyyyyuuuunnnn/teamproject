package com.trinity.weaver.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.QstnDao;

public class QstnInsertService implements WeaverService{
	private SqlSession sqlSession = Constant.sqlSession;

	@Override
	public void execute(Model model) {
		Map<String, Object> map = model.asMap();
		HttpServletRequest request = (HttpServletRequest) map.get("request");
		
		//시퀀스나 디폴트값이 생성된 경우 제외함
		String qstncat_name = request.getParameter("qstncat_name");
		int cust_idx = Integer.parseInt(request.getParameter("cust_idx"));
		String qstnbrd_title = request.getParameter("qstnbrd_title");
		String qstnbrd_content = request.getParameter("qstnbrd_content");
		String qstnbrd_imgName = request.getParameter("qstnbrd_imgName");
		String qstnbrd_imgPath = request.getParameter("qstnbrd_imgPath");
		String qstnbrd_pw = request.getParameter("qstnbrd_pw");
		
		QstnDao dao = sqlSession.getMapper(QstnDao.class);
		dao.qstnInsert(qstncat_name, cust_idx, qstnbrd_title, qstnbrd_content, qstnbrd_imgName, qstnbrd_imgPath, qstnbrd_pw);
		
	}

}
