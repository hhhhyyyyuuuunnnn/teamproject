package com.trinity.weaver;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.trinity.weaver.service.Constant;
import com.trinity.weaver.service.ProdListService;
import com.trinity.weaver.service.ProdRevListService;
import com.trinity.weaver.service.ProdRevWriteService;
import com.trinity.weaver.service.WeaverService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	   // service 활용
	   WeaverService service;
	   SqlSession sqlSession;
	   
	   // 컨트롤러에서 SqlSession 객체를 사용하기 위한 코드, "@Autowired"이 붙으면 무조건 수행됨.
	   @Autowired
	   public void setSqlSession(SqlSession sqlSession) {
	      this.sqlSession = sqlSession;
	      // 이 부분으로 인해, Contstant를 통해 다른 클래스들도 SqlSession 객체를 사용할 수 있음.
	         // 즉, 서블릿에서 생성 Constant 클래스로 보내줌.
	            // 따라서, 서비스에서 Constatn로 접근해서 SqlSession을 생성할 수 있음.
	      Constant.sqlSession = this.sqlSession;
	   }   
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "index";
	}

	   @RequestMapping("/login")
	   public String login(Model model) { 
	      return "login"; 
	   }	
	   @RequestMapping("/join")
	   public String join(Model model) { 
	      return "join"; 
	   }
	   @RequestMapping("/info")
	   public String info(Model model) { 
	      return "info"; 
	   }
	   @RequestMapping("/prodList")
	   public String prodList(Model model) { 
	      service = new ProdListService();
	      service.execute(model);
	      return "prodList"; 
	   }	   
	   
	   
	   
	   @RequestMapping("/ProdRevList")
	   public String prodRevList(Model model) { 
	      service = new ProdRevListService();
	      service.execute(model);
	      return "prodRevList"; 
	   }
	   
	   @RequestMapping("/prodRevWrite_view")
	   public String prodRevWrite(Model model) { 
	      service = new ProdRevListService();
	      service.execute(model);
	      return "prodRevWrite_view"; 
	   }	   
		@RequestMapping("/prodRevWrite")
		public String prodRevWrite(Model model, HttpServletRequest request) throws SQLException, IOException{
			model.addAttribute("request", request);
			service = new ProdRevWriteService();
			service.execute(model);
			return "redirect:ProdRevList";
		}		   
	   
	
}
