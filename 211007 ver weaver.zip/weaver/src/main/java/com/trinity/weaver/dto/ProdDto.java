package com.trinity.weaver.dto;

import java.util.Date;

public class ProdDto {
	private int prod_idx;
	private int prodCat_idx;
	private int prodOpt_idx;
	private String prod_name;
	private int prod_price;
	private int prod_stock;
	private String prod_desc;
	private int prod_revCnt;
	private int prod_avgScr;
	private String prod_imgName;
	private String prod_imgPath;
	private Date prod_regDate;
	private int prod_hit;
	
	public ProdDto() {}

	public ProdDto(int prod_idx, int prodCat_idx, int prodOpt_idx, String prod_name, int prod_price, int prod_stock,
			String prod_desc, int prod_revCnt, int prod_avgScr, String prod_imgName, String prod_imgPath,
			Date prod_regDate, int prod_hit) {
		super();
		this.prod_idx = prod_idx;
		this.prodCat_idx = prodCat_idx;
		this.prodOpt_idx = prodOpt_idx;
		this.prod_name = prod_name;
		this.prod_price = prod_price;
		this.prod_stock = prod_stock;
		this.prod_desc = prod_desc;
		this.prod_revCnt = prod_revCnt;
		this.prod_avgScr = prod_avgScr;
		this.prod_imgName = prod_imgName;
		this.prod_imgPath = prod_imgPath;
		this.prod_regDate = prod_regDate;
		this.prod_hit = prod_hit;
	}

	public int getProd_idx() {
		return prod_idx;
	}

	public void setProd_idx(int prod_idx) {
		this.prod_idx = prod_idx;
	}

	public int getProdCat_idx() {
		return prodCat_idx;
	}

	public void setProdCat_idx(int prodCat_idx) {
		this.prodCat_idx = prodCat_idx;
	}

	public int getProdOpt_idx() {
		return prodOpt_idx;
	}

	public void setProdOpt_idx(int prodOpt_idx) {
		this.prodOpt_idx = prodOpt_idx;
	}

	public String getProd_name() {
		return prod_name;
	}

	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}

	public int getProd_price() {
		return prod_price;
	}

	public void setProd_price(int prod_price) {
		this.prod_price = prod_price;
	}

	public int getProd_stock() {
		return prod_stock;
	}

	public void setProd_stock(int prod_stock) {
		this.prod_stock = prod_stock;
	}

	public String getProd_desc() {
		return prod_desc;
	}

	public void setProd_desc(String prod_desc) {
		this.prod_desc = prod_desc;
	}

	public int getProd_revCnt() {
		return prod_revCnt;
	}

	public void setProd_revCnt(int prod_revCnt) {
		this.prod_revCnt = prod_revCnt;
	}

	public int getProd_avgScr() {
		return prod_avgScr;
	}

	public void setProd_avgScr(int prod_avgScr) {
		this.prod_avgScr = prod_avgScr;
	}

	public String getProd_imgName() {
		return prod_imgName;
	}

	public void setProd_imgName(String prod_imgName) {
		this.prod_imgName = prod_imgName;
	}

	public String getProd_imgPath() {
		return prod_imgPath;
	}

	public void setProd_imgPath(String prod_imgPath) {
		this.prod_imgPath = prod_imgPath;
	}

	public Date getProd_regDate() {
		return prod_regDate;
	}

	public void setProd_regDate(Date prod_regDate) {
		this.prod_regDate = prod_regDate;
	}

	public int getProd_hit() {
		return prod_hit;
	}

	public void setProd_hit(int prod_hit) {
		this.prod_hit = prod_hit;
	}
	
	
}
