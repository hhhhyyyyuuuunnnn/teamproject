package com.trinity.weaver.service;

import org.springframework.ui.Model;

public interface WeaverService {
   // Model은 UI에 활용할 정보 담는 창구.(자동으로 return됨.)
   public void execute(Model model);
}
