package com.trinity.weaver.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.ui.Model;

import com.trinity.weaver.dao.ProdRevDao;


public class ProdRevWriteService implements WeaverService{
	private SqlSession sqlSession = Constant.sqlSession;
	@Override
	public void execute(Model model) {
		Map<String, Object> map = model.asMap();
		HttpServletRequest request = (HttpServletRequest) map.get("request");
		String prodRevTitle = request.getParameter("prodRevTitle");
		String prodRevContent = request.getParameter("prodRevContent");
		int prodRevScore = Integer.parseInt(request.getParameter("prodRevScore"));
		ProdRevDao dao = sqlSession.getMapper(ProdRevDao.class);
		dao.write(prodRevTitle, prodRevContent, prodRevScore);
	}
	
}
