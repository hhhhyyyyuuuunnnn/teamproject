package com.trinity.weaver.dao;

import java.util.ArrayList;

import com.trinity.weaver.dto.ProdDto;

public interface ProdDao {
	//리스트 조회
	public ArrayList<ProdDto> prodList();
	//제품 등록
	public void prodInsert(final String prod_name, final int prod_price, final int prod_stock, final String prod_desc, final String prod_imgName, final String prod_imgPath); //이미지,,, 카테코리,, 옵션
	
	
}
